# P2-HYB-01 — 현재 관리·인수 스냅샷

기준 2026-10-19T19:25:19.982565+09:00. 미발행 정본 후보 / CODEX_ASSISTED. [GitHub 원본](https://github.com/321Team/fds-project-baseline/issues/47) · updated_at `2026-10-19T09:39:02Z` · body SHA256 `c7b87656feb9c2ced065ac4ea9bca3323f3a955ee9b4038b3673e90eb7d64315`. 아래 속성표는 현행이며, 발행 v3.1.21 원본은 수정하지 않았다.

| Property | 현재 입력값 |
|---|---|
| Record ID | P2-HYB-01 |
| Phase | Phase 2 |
| Category | Hybrid Integration |
| Type | Task |
| Status | In Progress |
| Priority | P0 |
| Start | 2026-10-21 |
| End | 2026-10-21 |
| Calendar Days | 1 |
| Working Days | 1 |
| Lead | 이재환 |
| Support | 이권욱, 이하영 |
| Exit Criteria | ROSA→On-Prem db01 .55:5432와 승인 Registry 경로의 Route·Security·Source·Application 통합 검증 PASS |
| Related Decision IDs | D21; D22; D23 |
| Related Risk IDs | RISK-09; RISK-10; RISK-11; RISK-12 |
| Source | Baseline v3.1.18; Ticket Pack v3.1.18; GitHub #47 snapshot 2026-09-10T02:09:59Z; 현행 발행 정본: docs-v3.1.21 (979facb98de8ca1f1e2ce22f38b27ac3366f3fc3); 수집 후 실행 기록은 본문 최신 증적 기준 |
| Schedule Note | 10-20 G5 이전에는 read-only/precheck·입력 준비만 수행하고, 10-20 G5 완료 후 10-21 단일 Runtime window에서 Hybrid DB/Registry 통합을 검증해 #50에 인계한다. |

## 현재 원 AC — 체크 상태 보존

- [ ] ROSA에서 DB 5432 승인 연결이 성공한다.
- [ ] Transaction/FDS Result 저장·조회가 성공한다.
- [ ] 미승인 Source가 차단된다.
- [ ] Registry 사용 시 Pull이 성공하고 미사용 시 Cancelled 결정 근거가 있다.

---

## 상태·원조건 추적

기존 승인·위험수용·미검증·Reviewer/Approver는 해당 GitHub 원문/댓글과 [Review 원조건 표](../REVIEW31_RESULTS_AND_DECISION_CARD.md)를 따른다. 상태 동기화가 원 AC를 완화하거나 미실행을 MET로 바꾸지 않는다.
